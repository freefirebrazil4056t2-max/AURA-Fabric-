# AURA 1.0 — Fabric / Minecraft 26.1.2

## Tính năng hiện tại
- Chỉ nhận AURA khi người chơi trực tiếp tiêu diệt mob thù địch (`Enemy`).
- Mỗi mạng hạ gục cộng 10 điểm.
- Điểm AURA được lưu cùng dữ liệu người chơi qua lần thoát game.
- Khi người chơi chết và hồi sinh, điểm AURA trở về 0.
- Có hạt năng lượng xung quanh người chơi khi có điểm AURA.
- Mỗi 1 giây, AURA gây sát thương phép lên mob thù địch gần người chơi.

## Mốc sức mạnh mặc định
| Điểm | Bán kính | Sát thương mỗi xung |
|---:|---:|---:|
| 1–99 | Chỉ có hiệu ứng hạt | 0 |
| 100–499 | 2 block | 1 HP |
| 500–999 | 4 block | 2 HP |
| 1000+ | 6 block | 4 HP |

## Yêu cầu
- Minecraft Java 26.1.2
- Fabric Loader 0.19.2 trở lên
- Fabric API 0.152.1+26.1.2
- JDK 25
- Gradle 9.5.1 hoặc bản tương thích với Loom 1.16-SNAPSHOT

## Build
Mở terminal tại thư mục dự án và chạy:

```bash
gradle build
```

Nếu dùng IntelliJ IDEA, mở thư mục dự án dưới dạng Gradle project. Sau khi Gradle sync thành công, chạy task `build`.

File mod được tạo tại:

`build/libs/aura-1.0.0.jar`

Chép file JAR vào thư mục `mods` của instance Fabric Minecraft 26.1.2.

## Lưu ý
Đây là bản source khởi đầu. Cần chạy Gradle build và thử nghiệm trong game trên đúng bộ Minecraft/Fabric nêu trên trước khi xem là bản phát hành đã kiểm thử. Các mốc điểm, sát thương và bán kính có thể chỉnh trong `AuraLogic.java`; điểm thưởng mỗi mạng chỉnh trong `AuraMod.java`.
