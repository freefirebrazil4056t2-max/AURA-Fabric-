package dev.aura;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;
import com.mojang.serialization.Codec;

public final class AuraData {
    private AuraData() {}

    // Persistent: dữ liệu được lưu cùng player. Không dùng copyOnDeath để không kế thừa khi chết.
    public static final AttachmentType<Integer> AURA_POINTS = AttachmentRegistry.create(
        Identifier.fromNamespaceAndPath(AuraMod.MOD_ID, "aura_points"),
        builder -> builder
            .initializer(() -> 0)
            .persistent(Codec.INT)
            .syncWith(ByteBufCodecs.VAR_INT, AttachmentSyncPredicate.targetOnly())
    );

    public static void init() {
        // Ép class được load trong lúc mod khởi tạo để đăng ký attachment.
    }

    public static int get(net.minecraft.world.entity.Entity entity) {
        return Math.max(0, entity.getAttachedOrElse(AURA_POINTS, 0));
    }

    public static int set(net.minecraft.world.entity.Entity entity, int points) {
        int safe = Math.max(0, points);
        entity.setAttached(AURA_POINTS, safe);
        return safe;
    }

    public static int add(net.minecraft.world.entity.Entity entity, int amount) {
        return set(entity, get(entity) + Math.max(0, amount));
    }
}
