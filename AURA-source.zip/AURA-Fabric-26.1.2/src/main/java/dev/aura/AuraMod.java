package dev.aura;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;

public final class AuraMod implements ModInitializer {
    public static final String MOD_ID = "aura";

    // Các thông số cân bằng ban đầu, có thể chỉnh trong AuraLogic.
    public static final int POINTS_PER_HOSTILE_KILL = 10;

    @Override
    public void onInitialize() {
        AuraData.init();

        // Chỉ cộng điểm khi người chơi trực tiếp hạ gục mob thù địch.
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register(
            (ServerLevel world, Entity killer, net.minecraft.world.entity.LivingEntity victim, DamageSource source) -> {
                if (killer instanceof ServerPlayer player && victim instanceof Enemy) {
                    int updated = AuraData.add(player, POINTS_PER_HOSTILE_KILL);
                    player.displayClientMessage(
                        Component.literal("§b✦ AURA +" + POINTS_PER_HOSTILE_KILL + " §7| Tổng: §f" + updated),
                        true
                    );
                }
            }
        );

        // Không mang điểm qua đời: đặt lại về 0 sau khi respawn.
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> AuraData.set(newPlayer, 0));

        // Aura hiển thị hạt thường xuyên; sát thương chỉ áp dụng mỗi 20 tick (1 giây).
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                int points = AuraData.get(player);
                if (points <= 0 || !player.isAlive()) continue;

                if (player.tickCount % 5 == 0) {
                    AuraLogic.spawnAuraParticles(player);
                }

                if (player.tickCount % 20 == 0) {
                    AuraLogic.pulseDamage(player, points);
                    player.displayClientMessage(
                        Component.literal("§b✦ AURA §f" + points + " §7| " + AuraLogic.getTierName(points)),
                        true
                    );
                }
            }
        });
    }
}
