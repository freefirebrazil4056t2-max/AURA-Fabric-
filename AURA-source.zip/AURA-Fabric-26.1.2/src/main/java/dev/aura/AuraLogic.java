package dev.aura;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;

public final class AuraLogic {
    private AuraLogic() {}

    public static int getRadius(int points) {
        if (points >= 1000) return 6;
        if (points >= 500) return 4;
        if (points >= 100) return 2;
        return 0;
    }

    public static float getDamage(int points) {
        if (points >= 1000) return 4.0F;
        if (points >= 500) return 2.0F;
        if (points >= 100) return 1.0F;
        return 0.0F;
    }

    public static String getTierName(int points) {
        if (points >= 1000) return "§cRED AURA";
        if (points >= 500) return "§5PURPLE AURA";
        if (points >= 100) return "§bBLUE AURA";
        return "§7Đang tích tụ";
    }

    public static void spawnAuraParticles(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        int points = AuraData.get(player);
        double radius = Math.max(0.8, Math.min(2.2, 0.8 + getRadius(points) * 0.18));
        double y = player.getY() + 0.9;

        // Vòng hạt năng lượng quanh thân người chơi.
        for (int i = 0; i < 10; i++) {
            double angle = (Math.PI * 2.0 * i / 10.0) + (player.tickCount * 0.08);
            double x = player.getX() + Math.cos(angle) * radius;
            double z = player.getZ() + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.02, 0.25, 0.02, 0.0);
        }
        level.sendParticles(ParticleTypes.ENCHANT, player.getX(), y, player.getZ(), 5, 0.45, 0.5, 0.45, 0.15);
    }

    public static void pulseDamage(ServerPlayer player, int points) {
        int radius = getRadius(points);
        float damage = getDamage(points);
        if (radius <= 0 || damage <= 0.0F) return;

        ServerLevel level = player.serverLevel();
        AABB area = player.getBoundingBox().inflate(radius);

        for (Mob mob : level.getEntitiesOfClass(
            Mob.class,
            area,
            candidate -> candidate.isAlive()
                && candidate instanceof Enemy
                && candidate.distanceToSqr(player) <= (double) radius * radius
        )) {
            mob.hurtServer(level, level.damageSources().magic(), damage);
        }

        // Một vòng xung kích ngắn khi AURA phát sát thương.
        level.sendParticles(
            ParticleTypes.SOUL_FIRE_FLAME,
            player.getX(), player.getY() + 0.8, player.getZ(),
            18, radius * 0.45, 0.35, radius * 0.45, 0.025
        );
    }
}
